package com.codepath.tajoirial.instagramclone;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseObject;
import com.parse.ParseUser;

public class ParseApplication extends Application {

    //initializes Parse SDK as soon as the application is created
    @Override
    public void onCreate() {
        super.onCreate();

        //register your parse models
        ParseObject.registerSubclass(Post.class);

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("wRs6iBXbWubNAmxn9vpRWL6qn4mF5iTUCV7PlSAO")
                .clientKey("5c3BJ5ACrlBGL0aFhmj3jaKU9aSBMYwRAZ7qz5D8")
                .server("https://parseapi.back4app.com")
                .build());
    }

    ;

}


